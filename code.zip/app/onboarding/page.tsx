"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { Loader2, ArrowRight, ArrowLeft, Check } from "lucide-react"

const steps = [
  {
    id: 1,
    title: "Parlez-nous de vous",
    description: "Aidez-nous à personnaliser votre expérience",
  },
  {
    id: 2,
    title: "Votre domaine d'expertise",
    description: "Dans quel domaine allez-vous créer des cours ?",
  },
  {
    id: 3,
    title: "Vos objectifs",
    description: "Que souhaitez-vous accomplir avec Nala ?",
  },
]

export default function OnboardingPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    role: "creator",
    bio: "",
    expertise: "",
    goals: [] as string[],
    experience: "",
  })

  const supabase = getSupabaseBrowserClient()

  useEffect(() => {
    const checkUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        router.push("/auth")
      }
    }
    checkUser()
  }, [router, supabase])

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleComplete = async () => {
    setIsLoading(true)
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (user) {
        // Update user metadata
        await supabase.auth.updateUser({
          data: {
            onboarding_completed: true,
            role: formData.role,
            bio: formData.bio,
            expertise: formData.expertise,
            goals: formData.goals,
            experience: formData.experience,
          },
        })

        router.push("/dashboard")
      }
    } catch (error) {
      console.error("Erreur lors de l'onboarding:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const toggleGoal = (goal: string) => {
    setFormData((prev) => ({
      ...prev,
      goals: prev.goals.includes(goal) ? prev.goals.filter((g) => g !== goal) : [...prev.goals, goal],
    }))
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-background via-background to-primary/5 px-4 py-12">
      <div className="w-full max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex flex-1 items-center">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full border-2 ${
                    currentStep >= step.id
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-background text-muted-foreground"
                  }`}
                >
                  {currentStep > step.id ? <Check className="h-5 w-5" /> : step.id}
                </div>
                {index < steps.length - 1 && (
                  <div className={`mx-2 h-1 flex-1 rounded ${currentStep > step.id ? "bg-primary" : "bg-border"}`} />
                )}
              </div>
            ))}
          </div>
        </div>

        <Card className="border-border shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl">{steps[currentStep - 1].title}</CardTitle>
            <CardDescription>{steps[currentStep - 1].description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {currentStep === 1 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Je suis...</Label>
                  <RadioGroup
                    value={formData.role}
                    onValueChange={(value) => setFormData({ ...formData, role: value })}
                  >
                    <div className="flex items-center space-x-2 rounded-lg border border-border p-4 hover:bg-accent/5">
                      <RadioGroupItem value="creator" id="creator" />
                      <Label htmlFor="creator" className="flex-1 cursor-pointer">
                        <div className="font-medium">Créateur de contenu</div>
                        <div className="text-sm text-muted-foreground">Je veux créer et vendre mes propres cours</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 rounded-lg border border-border p-4 hover:bg-accent/5">
                      <RadioGroupItem value="student" id="student" />
                      <Label htmlFor="student" className="flex-1 cursor-pointer">
                        <div className="font-medium">Étudiant</div>
                        <div className="text-sm text-muted-foreground">Je veux suivre des cours et apprendre</div>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Parlez-nous de vous</Label>
                  <Textarea
                    id="bio"
                    placeholder="Décrivez brièvement votre parcours et vos passions..."
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    rows={4}
                  />
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="expertise">Domaine d'expertise</Label>
                  <Input
                    id="expertise"
                    placeholder="Ex: Développement web, Marketing digital, Design..."
                    value={formData.expertise}
                    onChange={(e) => setFormData({ ...formData, expertise: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Niveau d'expérience</Label>
                  <RadioGroup
                    value={formData.experience}
                    onValueChange={(value) => setFormData({ ...formData, experience: value })}
                  >
                    <div className="flex items-center space-x-2 rounded-lg border border-border p-3">
                      <RadioGroupItem value="beginner" id="beginner" />
                      <Label htmlFor="beginner" className="flex-1 cursor-pointer">
                        Débutant
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 rounded-lg border border-border p-3">
                      <RadioGroupItem value="intermediate" id="intermediate" />
                      <Label htmlFor="intermediate" className="flex-1 cursor-pointer">
                        Intermédiaire
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 rounded-lg border border-border p-3">
                      <RadioGroupItem value="expert" id="expert" />
                      <Label htmlFor="expert" className="flex-1 cursor-pointer">
                        Expert
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Vos objectifs (sélectionnez-en plusieurs)</Label>
                  <div className="space-y-2">
                    {[
                      { id: "income", label: "Générer des revenus passifs" },
                      { id: "audience", label: "Développer mon audience" },
                      { id: "expertise", label: "Partager mon expertise" },
                      { id: "community", label: "Créer une communauté" },
                      { id: "business", label: "Développer mon business" },
                    ].map((goal) => (
                      <div
                        key={goal.id}
                        onClick={() => toggleGoal(goal.id)}
                        className={`flex cursor-pointer items-center space-x-3 rounded-lg border p-4 transition-colors ${
                          formData.goals.includes(goal.id)
                            ? "border-primary bg-primary/5"
                            : "border-border hover:bg-accent/5"
                        }`}
                      >
                        <div
                          className={`flex h-5 w-5 items-center justify-center rounded border-2 ${
                            formData.goals.includes(goal.id) ? "border-primary bg-primary" : "border-border"
                          }`}
                        >
                          {formData.goals.includes(goal.id) && <Check className="h-3 w-3 text-primary-foreground" />}
                        </div>
                        <span className="font-medium">{goal.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={handleBack} disabled={currentStep === 1}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Retour
              </Button>

              {currentStep < steps.length ? (
                <Button onClick={handleNext}>
                  Suivant
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button onClick={handleComplete} disabled={isLoading}>
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Terminer
                  <Check className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
