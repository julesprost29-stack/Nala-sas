import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, X } from "lucide-react"
import Link from "next/link"

const plans = [
  {
    name: "Gratuit",
    price: "0€",
    period: "/mois",
    description: "Parfait pour commencer et tester la plateforme",
    features: [
      { text: "1 cours", included: true },
      { text: "50 étudiants max", included: true },
      { text: "Commission de 10%", included: true },
      { text: "Support par email", included: true },
      { text: "Analytics de base", included: true },
      { text: "Marketplace", included: false },
      { text: "Domaine personnalisé", included: false },
      { text: "Support prioritaire", included: false },
    ],
    cta: "Commencer gratuitement",
    href: "/auth?mode=signup",
    popular: false,
  },
  {
    name: "Pro",
    price: "29€",
    period: "/mois",
    description: "Pour les créateurs sérieux qui veulent développer leur activité",
    features: [
      { text: "Cours illimités", included: true },
      { text: "Étudiants illimités", included: true },
      { text: "Commission de 5%", included: true },
      { text: "Support prioritaire", included: true },
      { text: "Analytics avancés", included: true },
      { text: "Marketplace", included: true },
      { text: "Domaine personnalisé", included: true },
      { text: "Certificats personnalisés", included: true },
    ],
    cta: "Essayer Pro",
    href: "/auth?mode=signup&plan=pro",
    popular: true,
  },
  {
    name: "Business",
    price: "99€",
    period: "/mois",
    description: "Pour les équipes et organisations avec des besoins avancés",
    features: [
      { text: "Tout de Pro, plus:", included: true },
      { text: "Équipe multi-utilisateurs", included: true },
      { text: "Commission de 3%", included: true },
      { text: "Support dédié 24/7", included: true },
      { text: "API personnalisée", included: true },
      { text: "Intégrations avancées", included: true },
      { text: "Formation personnalisée", included: true },
      { text: "SLA garanti", included: true },
    ],
    cta: "Contacter les ventes",
    href: "/contact?plan=business",
    popular: false,
  },
]

const faqs = [
  {
    question: "Puis-je changer de plan à tout moment ?",
    answer:
      "Oui, vous pouvez passer à un plan supérieur ou inférieur à tout moment. Les changements prennent effet immédiatement.",
  },
  {
    question: "Comment fonctionne la commission ?",
    answer:
      "Nous prenons une petite commission sur chaque vente de cours. Plus votre plan est élevé, plus la commission est faible.",
  },
  {
    question: "Y a-t-il des frais cachés ?",
    answer: "Non, aucun frais caché. Vous ne payez que l'abonnement mensuel et la commission sur les ventes.",
  },
  {
    question: "Puis-je annuler mon abonnement ?",
    answer: "Oui, vous pouvez annuler à tout moment. Votre accès restera actif jusqu'à la fin de la période payée.",
  },
]

export default function PricingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="border-b border-border bg-gradient-to-b from-background to-muted/30 py-20">
          <div className="container mx-auto px-4 text-center">
            <h1 className="mb-4 text-balance text-4xl font-bold text-foreground md:text-5xl lg:text-6xl">
              Des tarifs simples et transparents
            </h1>
            <p className="mx-auto mb-8 max-w-2xl text-pretty text-lg text-muted-foreground md:text-xl">
              Choisissez le plan qui correspond à vos besoins. Commencez gratuitement et évoluez à votre rythme.
            </p>
          </div>
        </section>

        {/* Pricing Cards */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 lg:grid-cols-3">
              {plans.map((plan) => (
                <Card
                  key={plan.name}
                  className={`relative flex flex-col ${
                    plan.popular ? "border-primary shadow-lg ring-2 ring-primary/20" : "border-border"
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <span className="rounded-full bg-primary px-4 py-1 text-sm font-semibold text-primary-foreground">
                        Plus populaire
                      </span>
                    </div>
                  )}

                  <CardHeader>
                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    <CardDescription className="text-base">{plan.description}</CardDescription>
                    <div className="mt-4">
                      <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                      <span className="text-muted-foreground">{plan.period}</span>
                    </div>
                  </CardHeader>

                  <CardContent className="flex-1">
                    <ul className="space-y-3">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-3">
                          {feature.included ? (
                            <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-success/10">
                              <Check className="h-3.5 w-3.5 text-success" />
                            </div>
                          ) : (
                            <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-muted">
                              <X className="h-3.5 w-3.5 text-muted-foreground" />
                            </div>
                          )}
                          <span className={feature.included ? "text-foreground" : "text-muted-foreground"}>
                            {feature.text}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>

                  <CardFooter>
                    <Button className="w-full" variant={plan.popular ? "default" : "outline"} size="lg" asChild>
                      <Link href={plan.href}>{plan.cta}</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>

            <div className="mt-12 text-center">
              <p className="text-muted-foreground">
                Tous les plans incluent un essai gratuit de 14 jours. Aucune carte bancaire requise.
              </p>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="border-t border-border bg-muted/30 py-20">
          <div className="container mx-auto px-4">
            <div className="mb-12 text-center">
              <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">Questions fréquentes</h2>
              <p className="text-lg text-muted-foreground">Vous avez des questions ? Nous avons les réponses.</p>
            </div>

            <div className="mx-auto max-w-3xl space-y-6">
              {faqs.map((faq, index) => (
                <Card key={index} className="border-border">
                  <CardHeader>
                    <CardTitle className="text-xl">{faq.question}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{faq.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="mt-12 text-center">
              <p className="mb-4 text-muted-foreground">Vous avez d'autres questions ?</p>
              <Button variant="outline" asChild>
                <Link href="/contact">Contactez-nous</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="border-t border-border py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">Prêt à commencer votre aventure ?</h2>
            <p className="mb-8 text-lg text-muted-foreground">
              Rejoignez des milliers de créateurs qui partagent déjà leur expertise sur Nala
            </p>
            <Button size="lg" asChild>
              <Link href="/auth?mode=signup">Créer mon compte gratuitement</Link>
            </Button>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
