"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { ChevronLeft, ChevronRight, CheckCircle, PlayCircle, Menu, X, Download } from "lucide-react"
import Link from "next/link"

const course = {
  id: 1,
  title: "Maîtriser React et Next.js",
  progress: 45,
  modules: [
    {
      id: 1,
      title: "Introduction à React",
      lessons: [
        { id: 1, title: "Qu'est-ce que React ?", duration: "10:30", completed: true },
        { id: 2, title: "Installation et configuration", duration: "15:20", completed: true },
        { id: 3, title: "Votre premier composant", duration: "12:45", completed: false },
      ],
    },
    {
      id: 2,
      title: "Les fondamentaux",
      lessons: [
        { id: 4, title: "JSX et les composants", duration: "18:30", completed: false },
        { id: 5, title: "Props et State", duration: "20:15", completed: false },
        { id: 6, title: "Exercice pratique", duration: "30:00", completed: false },
      ],
    },
  ],
}

export default function LearnPage({ params }: { params: { id: string } }) {
  const [currentLesson, setCurrentLesson] = useState(3)
  const [sidebarOpen, setSidebarOpen] = useState(true)

  const currentLessonData = course.modules.flatMap((m) => m.lessons).find((l) => l.id === currentLesson)

  const allLessons = course.modules.flatMap((m) => m.lessons)
  const currentIndex = allLessons.findIndex((l) => l.id === currentLesson)
  const hasNext = currentIndex < allLessons.length - 1
  const hasPrevious = currentIndex > 0

  const handleNext = () => {
    if (hasNext) {
      setCurrentLesson(allLessons[currentIndex + 1].id)
    }
  }

  const handlePrevious = () => {
    if (hasPrevious) {
      setCurrentLesson(allLessons[currentIndex - 1].id)
    }
  }

  return (
    <div className="flex h-screen flex-col bg-background">
      {/* Top Bar */}
      <header className="flex h-16 items-center justify-between border-b border-border px-4">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
          <div>
            <Link href={`/courses/${params.id}`} className="text-sm text-muted-foreground hover:text-foreground">
              ← Retour au cours
            </Link>
            <h1 className="font-semibold">{course.title}</h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden items-center gap-2 md:flex">
            <span className="text-sm text-muted-foreground">Progression:</span>
            <div className="w-32">
              <Progress value={course.progress} className="h-2" />
            </div>
            <span className="text-sm font-medium">{course.progress}%</span>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        {sidebarOpen && (
          <aside className="w-80 overflow-y-auto border-r border-border bg-card">
            <div className="p-4">
              <h2 className="mb-4 font-semibold">Contenu du cours</h2>
              <div className="space-y-2">
                {course.modules.map((module) => (
                  <div key={module.id}>
                    <div className="mb-2 font-medium text-sm">{module.title}</div>
                    <div className="space-y-1">
                      {module.lessons.map((lesson) => (
                        <button
                          key={lesson.id}
                          onClick={() => setCurrentLesson(lesson.id)}
                          className={`flex w-full items-center gap-3 rounded-lg p-3 text-left transition-colors ${
                            currentLesson === lesson.id ? "bg-primary text-primary-foreground" : "hover:bg-accent"
                          }`}
                        >
                          {lesson.completed ? (
                            <CheckCircle className="h-4 w-4 flex-shrink-0 text-success" />
                          ) : (
                            <PlayCircle className="h-4 w-4 flex-shrink-0" />
                          )}
                          <div className="flex-1">
                            <div className="text-sm font-medium">{lesson.title}</div>
                            <div className="text-xs opacity-80">{lesson.duration}</div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </aside>
        )}

        {/* Main Content */}
        <main className="flex flex-1 flex-col overflow-y-auto">
          {/* Video Player */}
          <div className="aspect-video w-full bg-black">
            <div className="flex h-full items-center justify-center">
              <PlayCircle className="h-20 w-20 text-white opacity-80" />
            </div>
          </div>

          {/* Lesson Content */}
          <div className="flex-1 p-6">
            <div className="mx-auto max-w-4xl">
              <h2 className="mb-4 text-2xl font-bold">{currentLessonData?.title}</h2>

              <div className="mb-6 flex items-center gap-4">
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  disabled={!hasPrevious}
                  className="gap-2 bg-transparent"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Précédent
                </Button>
                <Button onClick={handleNext} disabled={!hasNext} className="gap-2">
                  Suivant
                  <ChevronRight className="h-4 w-4" />
                </Button>
                <Button variant="outline" className="ml-auto gap-2 bg-transparent">
                  <CheckCircle className="h-4 w-4" />
                  Marquer comme terminé
                </Button>
              </div>

              <Separator className="my-6" />

              {/* Tabs */}
              <div className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="mb-4 font-semibold">Description</h3>
                    <p className="text-muted-foreground">
                      Dans cette leçon, vous allez apprendre les concepts fondamentaux de React. Nous couvrirons les
                      composants, le JSX, et comment structurer votre première application React.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="mb-4 font-semibold">Ressources</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                        <Download className="h-4 w-4" />
                        Télécharger le code source
                      </Button>
                      <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                        <Download className="h-4 w-4" />
                        Télécharger les slides
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="mb-4 font-semibold">Notes</h3>
                    <textarea
                      className="min-h-[150px] w-full rounded-lg border border-border bg-background p-3 text-sm"
                      placeholder="Prenez des notes pendant le cours..."
                    />
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
