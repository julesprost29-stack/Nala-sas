import { getUser } from "@/lib/supabase/server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Clock, Users, Star, PlayCircle, CheckCircle, BookOpen, Award } from "lucide-react"
import Link from "next/link"

const course = {
  id: 1,
  title: "Maîtriser React et Next.js",
  description:
    "Apprenez à créer des applications web modernes et performantes avec React et Next.js. Ce cours complet vous guidera des bases jusqu'aux concepts avancés.",
  thumbnail: "/placeholder.svg?key=nvq7l",
  price: 49.99,
  rating: 4.8,
  reviewsCount: 234,
  studentsCount: 2345,
  duration: "12h 30min",
  lessonsCount: 24,
  level: "Intermédiaire",
  category: "Développement Web",
  language: "Français",
  lastUpdated: "Mars 2024",
  creator: {
    name: "Jean Dupont",
    avatar: "/placeholder.svg?key=4eha3",
    title: "Développeur Full-Stack",
    studentsCount: 5000,
    coursesCount: 8,
  },
  learningPoints: [
    "Maîtriser les fondamentaux de React",
    "Créer des applications avec Next.js 14",
    "Gérer l'état avec React Hooks",
    "Implémenter le Server-Side Rendering",
    "Optimiser les performances",
    "Déployer sur Vercel",
  ],
  requirements: [
    "Connaissances de base en JavaScript",
    "Familiarité avec HTML et CSS",
    "Un ordinateur avec Node.js installé",
  ],
  modules: [
    {
      id: 1,
      title: "Introduction à React",
      lessons: [
        { id: 1, title: "Qu'est-ce que React ?", duration: "10:30", isPreview: true },
        { id: 2, title: "Installation et configuration", duration: "15:20", isPreview: true },
        { id: 3, title: "Votre premier composant", duration: "12:45", isPreview: false },
      ],
    },
    {
      id: 2,
      title: "Les fondamentaux",
      lessons: [
        { id: 4, title: "JSX et les composants", duration: "18:30", isPreview: false },
        { id: 5, title: "Props et State", duration: "20:15", isPreview: false },
        { id: 6, title: "Exercice pratique", duration: "30:00", isPreview: false },
      ],
    },
  ],
}

export default async function CoursePage({ params }: { params: { id: string } }) {
  const user = await getUser()

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="border-b border-border bg-gradient-to-br from-background via-background to-primary/5 py-12">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 lg:grid-cols-3">
              {/* Left Column - Course Info */}
              <div className="lg:col-span-2">
                <div className="mb-4 flex items-center gap-2">
                  <Badge>{course.category}</Badge>
                  <Badge variant="outline">{course.level}</Badge>
                </div>

                <h1 className="mb-4 text-4xl font-bold text-foreground">{course.title}</h1>
                <p className="mb-6 text-lg text-muted-foreground">{course.description}</p>

                <div className="mb-6 flex flex-wrap items-center gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{course.rating}</span>
                    <span className="text-muted-foreground">({course.reviewsCount} avis)</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>{course.studentsCount} étudiants</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <BookOpen className="h-4 w-4" />
                    <span>{course.lessonsCount} leçons</span>
                  </div>
                </div>

                {/* Creator Info */}
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={course.creator.avatar || "/placeholder.svg"} alt={course.creator.name} />
                    <AvatarFallback>
                      {course.creator.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">Créé par {course.creator.name}</div>
                    <div className="text-sm text-muted-foreground">{course.creator.title}</div>
                  </div>
                </div>
              </div>

              {/* Right Column - Purchase Card */}
              <div className="lg:col-span-1">
                <Card className="sticky top-4">
                  <div className="aspect-video w-full overflow-hidden rounded-t-lg bg-muted">
                    <img
                      src={course.thumbnail || "/placeholder.svg"}
                      alt={course.title}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6">
                    <div className="mb-4">
                      <div className="text-3xl font-bold">{course.price} €</div>
                    </div>

                    {user ? (
                      <Button asChild className="w-full" size="lg">
                        <Link href={`/courses/${params.id}/learn`}>
                          <PlayCircle className="mr-2 h-5 w-5" />
                          Commencer le cours
                        </Link>
                      </Button>
                    ) : (
                      <Button asChild className="w-full" size="lg">
                        <Link href="/auth?mode=signup">S'inscrire pour acheter</Link>
                      </Button>
                    )}

                    <Separator className="my-4" />

                    <div className="space-y-3 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Durée totale</span>
                        <span className="font-medium">{course.duration}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Leçons</span>
                        <span className="font-medium">{course.lessonsCount}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Niveau</span>
                        <span className="font-medium">{course.level}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Langue</span>
                        <span className="font-medium">{course.language}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Certificat</span>
                        <Award className="h-4 w-4 text-primary" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Course Content */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 lg:grid-cols-3">
              <div className="lg:col-span-2">
                {/* What You'll Learn */}
                <div className="mb-8">
                  <h2 className="mb-4 text-2xl font-bold">Ce que vous allez apprendre</h2>
                  <Card>
                    <CardContent className="p-6">
                      <div className="grid gap-3 md:grid-cols-2">
                        {course.learningPoints.map((point, index) => (
                          <div key={index} className="flex items-start gap-2">
                            <CheckCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-success" />
                            <span>{point}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Course Content */}
                <div className="mb-8">
                  <h2 className="mb-4 text-2xl font-bold">Contenu du cours</h2>
                  <Card>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {course.modules.map((module) => (
                          <div key={module.id} className="rounded-lg border border-border">
                            <div className="bg-muted/30 p-4">
                              <h3 className="font-semibold">{module.title}</h3>
                              <p className="text-sm text-muted-foreground">{module.lessons.length} leçons</p>
                            </div>
                            <div className="divide-y divide-border">
                              {module.lessons.map((lesson) => (
                                <div key={lesson.id} className="flex items-center justify-between p-4">
                                  <div className="flex items-center gap-3">
                                    <PlayCircle className="h-4 w-4 text-muted-foreground" />
                                    <span>{lesson.title}</span>
                                    {lesson.isPreview && (
                                      <Badge variant="secondary" className="text-xs">
                                        Aperçu
                                      </Badge>
                                    )}
                                  </div>
                                  <span className="text-sm text-muted-foreground">{lesson.duration}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Requirements */}
                <div className="mb-8">
                  <h2 className="mb-4 text-2xl font-bold">Prérequis</h2>
                  <Card>
                    <CardContent className="p-6">
                      <ul className="space-y-2">
                        {course.requirements.map((req, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <div className="mt-1 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-foreground" />
                            <span>{req}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                {/* Creator Card */}
                <Card className="mb-6">
                  <CardContent className="p-6">
                    <h3 className="mb-4 font-semibold">À propos du créateur</h3>
                    <div className="mb-4 flex items-center gap-3">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={course.creator.avatar || "/placeholder.svg"} alt={course.creator.name} />
                        <AvatarFallback>
                          {course.creator.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{course.creator.name}</div>
                        <div className="text-sm text-muted-foreground">{course.creator.title}</div>
                      </div>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Étudiants</span>
                        <span className="font-medium">{course.creator.studentsCount}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Cours</span>
                        <span className="font-medium">{course.creator.coursesCount}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
