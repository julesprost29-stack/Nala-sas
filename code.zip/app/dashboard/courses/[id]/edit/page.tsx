"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Save, Eye } from "lucide-react"
import Link from "next/link"
import { CourseContentEditor } from "@/components/course/content-editor"
import { CourseSettings } from "@/components/course/settings"
import { CourseModules } from "@/components/course/modules"

export default function EditCoursePage({ params }: { params: { id: string } }) {
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    setIsSaving(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsSaving(false)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/dashboard/courses">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Modifier le cours</h1>
            <p className="text-muted-foreground">Maîtriser React et Next.js</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" asChild>
            <Link href={`/courses/${params.id}`}>
              <Eye className="mr-2 h-4 w-4" />
              Prévisualiser
            </Link>
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            <Save className="mr-2 h-4 w-4" />
            {isSaving ? "Enregistrement..." : "Enregistrer"}
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="content" className="space-y-6">
        <TabsList>
          <TabsTrigger value="content">Contenu</TabsTrigger>
          <TabsTrigger value="modules">Modules & Leçons</TabsTrigger>
          <TabsTrigger value="settings">Paramètres</TabsTrigger>
        </TabsList>

        <TabsContent value="content" className="space-y-6">
          <CourseContentEditor />
        </TabsContent>

        <TabsContent value="modules" className="space-y-6">
          <CourseModules />
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <CourseSettings />
        </TabsContent>
      </Tabs>
    </div>
  )
}
