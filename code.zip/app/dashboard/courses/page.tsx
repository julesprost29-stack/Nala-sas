import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Users, DollarSign, MoreVertical, Edit, Trash2, Eye } from "lucide-react"
import Link from "next/link"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const courses = [
  {
    id: 1,
    title: "Maîtriser React et Next.js",
    description: "Apprenez à créer des applications web modernes",
    status: "published",
    students: 234,
    revenue: 4680,
    lessons: 24,
    thumbnail: "/react-nextjs-course.jpg",
  },
  {
    id: 2,
    title: "Marketing Digital pour Débutants",
    description: "Les bases du marketing en ligne",
    status: "draft",
    students: 0,
    revenue: 0,
    lessons: 12,
    thumbnail: "/digital-marketing-course.png",
  },
  {
    id: 3,
    title: "Design UI/UX Moderne",
    description: "Créez des interfaces utilisateur exceptionnelles",
    status: "published",
    students: 156,
    revenue: 3120,
    lessons: 18,
    thumbnail: "/ui-ux-design-course.png",
  },
]

export default function CoursesPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Mes cours</h1>
          <p className="text-muted-foreground">Gérez et créez vos cours en ligne</p>
        </div>
        <Button asChild className="gap-2">
          <Link href="/dashboard/courses/create">
            <Plus className="h-4 w-4" />
            Nouveau cours
          </Link>
        </Button>
      </div>

      {/* Courses Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {courses.map((course) => (
          <Card key={course.id} className="overflow-hidden">
            <div className="aspect-video w-full overflow-hidden bg-muted">
              <img
                src={course.thumbnail || "/placeholder.svg"}
                alt={course.title}
                className="h-full w-full object-cover"
              />
            </div>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="line-clamp-1">{course.title}</CardTitle>
                  <CardDescription className="line-clamp-2">{course.description}</CardDescription>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <Link href={`/dashboard/courses/${course.id}/edit`}>
                        <Edit className="mr-2 h-4 w-4" />
                        Modifier
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href={`/courses/${course.id}`}>
                        <Eye className="mr-2 h-4 w-4" />
                        Voir
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive">
                      <Trash2 className="mr-2 h-4 w-4" />
                      Supprimer
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <Badge variant={course.status === "published" ? "default" : "secondary"}>
                    {course.status === "published" ? "Publié" : "Brouillon"}
                  </Badge>
                  <span className="text-muted-foreground">{course.lessons} leçons</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>{course.students} étudiants</span>
                  </div>
                  <div className="flex items-center gap-1 font-medium text-success">
                    <DollarSign className="h-4 w-4" />
                    <span>{course.revenue} €</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
