import { createServerClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DollarSign, TrendingUp, Users, CreditCard } from "lucide-react"

async function getBillingData() {
  const supabase = await createServerClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  // Get total revenue
  const { data: payments } = await supabase
    .from("payments")
    .select("amount")
    .eq("instructor_id", user.id)
    .eq("status", "completed")

  const totalRevenue = payments?.reduce((sum, p) => sum + p.amount, 0) || 0

  // Get monthly revenue
  const startOfMonth = new Date()
  startOfMonth.setDate(1)
  startOfMonth.setHours(0, 0, 0, 0)

  const { data: monthlyPayments } = await supabase
    .from("payments")
    .select("amount")
    .eq("instructor_id", user.id)
    .eq("status", "completed")
    .gte("paid_at", startOfMonth.toISOString())

  const monthlyRevenue = monthlyPayments?.reduce((sum, p) => sum + p.amount, 0) || 0

  // Get recent transactions
  const { data: transactions } = await supabase
    .from("payments")
    .select(`
      *,
      courses (title),
      profiles (full_name)
    `)
    .eq("instructor_id", user.id)
    .order("paid_at", { ascending: false })
    .limit(10)

  return {
    totalRevenue,
    monthlyRevenue,
    transactionCount: payments?.length || 0,
    transactions: transactions || [],
  }
}

export default async function BillingPage() {
  const data = await getBillingData()

  if (!data) {
    return <div>Chargement...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Facturation</h1>
        <p className="text-muted-foreground mt-2">Gérez vos revenus et vos paiements</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Revenus totaux</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalRevenue.toFixed(2)} €</div>
            <p className="text-xs text-muted-foreground">Depuis le début</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ce mois</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.monthlyRevenue.toFixed(2)} €</div>
            <p className="text-xs text-muted-foreground">Revenus du mois en cours</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transactions</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.transactionCount}</div>
            <p className="text-xs text-muted-foreground">Total des ventes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Revenu moyen</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {data.transactionCount > 0 ? (data.totalRevenue / data.transactionCount).toFixed(2) : "0.00"} €
            </div>
            <p className="text-xs text-muted-foreground">Par transaction</p>
          </CardContent>
        </Card>
      </div>

      {/* Transactions Table */}
      <Card>
        <CardHeader>
          <CardTitle>Transactions récentes</CardTitle>
          <CardDescription>Historique de vos paiements</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {data.transactions.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Aucune transaction pour le moment</p>
            ) : (
              <div className="space-y-2">
                {data.transactions.map((transaction: any) => (
                  <div key={transaction.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-1">
                      <p className="font-medium">{transaction.courses?.title}</p>
                      <p className="text-sm text-muted-foreground">{transaction.profiles?.full_name || "Étudiant"}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(transaction.paid_at).toLocaleDateString("fr-FR", {
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                        })}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg">{transaction.amount.toFixed(2)} €</p>
                      <span className="inline-flex items-center rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700">
                        Complété
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
