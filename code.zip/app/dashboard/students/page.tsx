import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Search, Mail, MoreVertical, TrendingUp, Users, BookOpen, Award } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const stats = [
  {
    title: "Total étudiants",
    value: "2,345",
    change: "+12.5%",
    icon: Users,
  },
  {
    title: "Étudiants actifs",
    value: "1,892",
    change: "+8.2%",
    icon: TrendingUp,
  },
  {
    title: "Cours complétés",
    value: "456",
    change: "+23.1%",
    icon: Award,
  },
  {
    title: "Taux de complétion moyen",
    value: "68%",
    change: "+5.4%",
    icon: BookOpen,
  },
]

const students = [
  {
    id: 1,
    name: "Sophie Martin",
    email: "sophie.m@example.com",
    avatar: "/placeholder.svg?key=ttu0e",
    enrolledCourses: 3,
    completedCourses: 1,
    progress: 72,
    lastActive: "Il y a 2 heures",
    status: "active",
  },
  {
    id: 2,
    name: "Thomas Dubois",
    email: "thomas.d@example.com",
    avatar: "/placeholder.svg?key=4eha3",
    enrolledCourses: 2,
    completedCourses: 2,
    progress: 100,
    lastActive: "Il y a 1 jour",
    status: "completed",
  },
  {
    id: 3,
    name: "Marie Laurent",
    email: "marie.l@example.com",
    avatar: "/placeholder.svg?key=921p1",
    enrolledCourses: 4,
    completedCourses: 0,
    progress: 45,
    lastActive: "Il y a 3 jours",
    status: "active",
  },
  {
    id: 4,
    name: "Lucas Bernard",
    email: "lucas.b@example.com",
    avatar: "/placeholder.svg?key=wur9v",
    enrolledCourses: 1,
    completedCourses: 0,
    progress: 15,
    lastActive: "Il y a 1 semaine",
    status: "inactive",
  },
]

export default function StudentsPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Étudiants</h1>
        <p className="text-muted-foreground">Gérez et suivez la progression de vos étudiants</p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-success">{stat.change} par rapport au mois dernier</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Students Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Liste des étudiants</CardTitle>
              <CardDescription>Tous vos étudiants inscrits à vos cours</CardDescription>
            </div>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Rechercher un étudiant..." className="pl-10" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Étudiant</TableHead>
                <TableHead>Cours inscrits</TableHead>
                <TableHead>Progression</TableHead>
                <TableHead>Dernière activité</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students.map((student) => (
                <TableRow key={student.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={student.avatar || "/placeholder.svg"} alt={student.name} />
                        <AvatarFallback>
                          {student.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{student.name}</div>
                        <div className="text-sm text-muted-foreground">{student.email}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div className="font-medium">{student.enrolledCourses} cours</div>
                      <div className="text-muted-foreground">{student.completedCourses} complétés</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Progression</span>
                        <span className="font-medium">{student.progress}%</span>
                      </div>
                      <Progress value={student.progress} className="h-2" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-muted-foreground">{student.lastActive}</span>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        student.status === "active"
                          ? "default"
                          : student.status === "completed"
                            ? "secondary"
                            : "outline"
                      }
                    >
                      {student.status === "active" ? "Actif" : student.status === "completed" ? "Complété" : "Inactif"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Mail className="mr-2 h-4 w-4" />
                          Envoyer un message
                        </DropdownMenuItem>
                        <DropdownMenuItem>Voir le profil</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">Retirer l'accès</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
