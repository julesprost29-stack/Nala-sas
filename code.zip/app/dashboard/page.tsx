import { getUser } from "@/lib/supabase/server"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { RevenueChart } from "@/components/dashboard/revenue-chart"
import { RecentStudents } from "@/components/dashboard/recent-students"
import { PopularCourses } from "@/components/dashboard/popular-courses"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function DashboardPage() {
  const user = await getUser()

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Bienvenue, {user?.user_metadata?.name || "Créateur"}</h1>
          <p className="text-muted-foreground">Voici un aperçu de vos performances</p>
        </div>
        <Button asChild className="gap-2">
          <Link href="/dashboard/courses/create">
            <Plus className="h-4 w-4" />
            Créer un cours
          </Link>
        </Button>
      </div>

      {/* Stats Cards */}
      <StatsCards />

      {/* Charts and Tables */}
      <div className="grid gap-6 lg:grid-cols-7">
        <div className="lg:col-span-4">
          <RevenueChart />
        </div>
        <div className="lg:col-span-3">
          <RecentStudents />
        </div>
      </div>

      {/* Popular Courses */}
      <PopularCourses />
    </div>
  )
}
