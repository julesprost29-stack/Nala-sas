import Stripe from "stripe"

export const getStripeServer = () => {
  const key = process.env.STRIPE_SECRET_KEY
  if (!key) {
    throw new Error("Stripe secret key is not configured")
  }
  return new Stripe(key, {
    apiVersion: "2024-11-20.acacia",
  })
}
